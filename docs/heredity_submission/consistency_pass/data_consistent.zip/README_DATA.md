# Data archive for the archaic-segment sharing manuscript

Every data file referenced in the main text or the Supporting Information is included
under `data/`. File names match the names used in the manuscript, in the Supporting
Information and in the analysis scripts of the public code repository
(https://github.com/bougtoir/denisovan-archaic-dna-analysis). The archive holds 23
files under `data/` together with this documentation file. Ten of them are the formal
machine-readable Supplementary Data 1-10 files cited in the article, namely
`population_metadata.csv`, `pairwise_sharing_corrected.csv`, `model_summary.csv`,
`sensitivity_analysis.csv`, `window_size_sensitivity.csv`, `profile_quality_checks.csv`,
`abo_focal_test.json`, `ancient_abo_summary.csv`, `ancient_abo_provenance.json` and
`analysis_provenance.json`; the remaining 13 are additional derived intermediate and
auxiliary files retained to support reproducibility and auditability.

The derived files included here are sufficient to inspect and recompute the summary
values reported in the manuscript tables and figures and in the Supporting Information.
Rerunning the complete upstream analysis from the original archaic-segment calls
additionally requires downloading the two large source segment files from Zenodo record
14136628, which are not redistributed here (see below).

## Redistribution status

All files below are derived summaries that we computed. They are redistributed here
under the terms of their upstream sources, with attribution:

- Archaic-segment calls for the 1000 Genomes Project and HGDP panels: Zenodo record
  14136628, "Archaic introgression for HGDP and 1000genomes in hg38" (Skov L),
  released under CC BY 4.0, which permits redistribution of the data and of derived
  works with attribution. The underlying panels (1000 Genomes Project and the HGDP
  collection of Bergstrom et al. 2020) are themselves openly released without access
  restriction, and the segment calls used here are published at individual level in
  that CC BY 4.0 record.
- Ancient-genome ABO interval summaries: Dryad dataset 10.5061/dryad.zw3r228gg,
  accompanying Iasi et al. (2024, Science, 10.1126/science.adq3010), released under
  CC0 1.0, which places the data in the public domain.

No file in this archive contains genotypes, sequence reads, phenotypes, or any
restricted-access or consent-limited material. The individual-level files
(`abo_neanderthal_segments.csv`, `abo_denisovan_segments.csv`,
`ancient_abo_summary.csv`) carry only the public sample identifiers and archaic
segment coordinates already published in the CC BY 4.0 and CC0 sources above.

The two large upstream input files (`hg38_1000g_segments.txt`, 1.06 GB, and
`hg38_HGDP_segments.txt`, 399 MB) are NOT redistributed here, to avoid duplicating a
1.5 GB archive that is already citable and permanently hosted. Download them from
Zenodo record 14136628 and verify them against the SHA-256 checksums recorded in
`data/analysis_provenance.json`:

- `hg38_1000g_segments.txt`: d3ea9fe7ac6b5abacb176acecf4747bacdead89c0a35e1750a4f8ee71b2bb1d4
- `hg38_HGDP_segments.txt`: c222d44a05fed3f059b2907ca6e9deb8899c41ff8fd59bc629bd57c910a593ac

## Files

### Primary analysis inputs and outputs

- `data/population_profiles_500kb.npz`: population-by-window archaic-segment frequency
  matrices (66 populations x 5,760 windows of 500 kb) for the Neanderthal and Denisovan
  profiles, with population labels, chromosomes and bin numbers. This is the matrix on
  which every pairwise comparison in the paper is computed.
- `data/population_metadata.csv`: the 66 retained populations with region, continent,
  source panel, sample size, sampling coordinates, European-admixture fraction and
  inclusion flags.
- `data/pairwise_sharing.csv`: all 2,145 population pairs with the similarity measures
  (Pearson, Spearman, cosine, Jaccard), geographic distance and pair covariates, before
  the structural correction.
- `data/pairwise_sharing_corrected.csv`: the same pairs after matrix regression, with
  fitted values, residuals, residual z scores, permutation P values and BH q values.
- `data/model_summary.csv`: matrix-regression coefficients with QAP permutation P values.
- `data/correction_stats.json` and `data/correction_stats.txt`: the headline statistics
  of the corrected analysis (raw and partial correlations, permutation counts, subset
  sizes) in machine-readable and human-readable form.
- `data/analysis_provenance.json`: the analysis release and analysis code commit, the
  input file names with their SHA-256 checksums, the minimum segment probability and
  minimum population size, the genomic bin size, the frequency definition, and the
  individual, population and pair counts.
- `data/enhanced_statistics.csv`: descriptive correlation and slope statistics from the
  exploratory uncorrected pass (distance correlations with nominal P values, partial
  correlations, non-admixed-subset correlations, the distance slope with its interval,
  pair counts, and counts of pairs with absolute residual z above two). The statistics
  reported in the manuscript come from `data/correction_stats.json`,
  `data/model_summary.csv` and `data/pairwise_sharing_corrected.csv`, not from this file.
- `data/profile_quality_checks.csv`: ancestry-level profile quality checks giving the
  maximum observed population-window frequency, the number of bins exceeding one, and
  the number of non-zero population-window entries.

### Residual-outlier and sensitivity files

- `data/neanderthal_outliers.csv` and `data/denisovan_outliers.csv`: pair-level residual
  rankings from the descriptive distance-only fit, with residuals, z scores and
  admixture flags. These are descriptive rankings; the dependence-aware residual z
  scores, permutation P values and Benjamini-Hochberg q values on which the reported
  pair-level test is based are in `data/pairwise_sharing_corrected.csv`.
- `data/outlier_summary.csv`: the record layout for pairs qualifying as supported
  positive outliers in Table 1, with the full covariate and residual fields. The file
  contains the header row only, because no pair met the prespecified criterion of a
  positive residual above two standard deviations together with a Benjamini-Hochberg q
  below 0.10.
- `data/sensitivity_analysis.csv`: results under alternative similarity measures,
  admixture-exclusion rules and covariate sets.
- `data/window_size_sensitivity.csv`: the population-wide geographic-distance
  association at 250-kb, 500-kb and 1-Mb window sizes, with the raw distance
  correlations, the QAP distance coefficients, the two-sided permutation P values and
  the descriptive R-squared values.

### ABO focal-locus worked example

- `data/abo_focal_test.json`: the prespecified ABO window test, with the maximum
  standardised excess-similarity score, its genome-wide percentile, the empirical P
  value and the number of usable windows, for both profiles.
- `data/abo_neanderthal_segments.csv` and `data/abo_denisovan_segments.csv`: the archaic
  segments overlapping the ABO window in present-day individuals, with the closest
  archaic reference and strict-overlap flag.
- `data/abo_population_summary.csv`: per-population counts and frequencies of
  ABO-window segments.
- `data/abo_sublineage_summary.csv`: proportions of ABO-window segments by closest
  archaic reference and analysis group.
- `data/ancient_abo_summary.csv` and `data/ancient_abo_provenance.json`: the 59 ancient
  individuals assessed in the ABO interval, of which 16 carry a detected Neanderthal
  segment and 8 a segment with strict ABO gene overlap, with age, population,
  closest-reference information and detection flags; and the provenance record for that
  summary (source article and data DOIs, GRCh37/hg19 genome build, interval coordinates,
  source file names and checksums). These summaries were generated by a different
  pipeline from the present-day profiles and are used descriptively only, without
  statistical comparison.
- `data/o2_frequency_summary.csv`: published ABO O2 allele frequencies used for context,
  with source citations and DOIs.
